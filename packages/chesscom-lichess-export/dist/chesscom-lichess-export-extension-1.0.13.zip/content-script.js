(function(){"use strict";let y=null;function F(t){y=t}function d(){if(!y)throw new Error("[cc2l] Platform not initialized");return y}function H(t){return d().http.postForm("https://lichess.org/api/import",`pgn=${encodeURIComponent(t)}`,{"Content-Type":"application/x-www-form-urlencoded",Accept:"application/json"}).then(e=>{if(e.status!==200)throw new Error(`Lichess API returned ${e.status}`);try{return JSON.parse(e.responseText)}catch{throw new Error("Failed to parse Lichess response")}})}const U=["/game/","/play/","/analysis/game/"],z=[".game-over-modal-header-is-v6-aborted",".game-over-aborted-body-component",".game-over-header-abortedIcon"],J=['[data-cy="game-over-modal-shell-buttons"]',".game-over-modal-shell-buttons",".game-over-buttons-component",'[data-cy="game-review-buttons-component"]',".game-review-buttons-component"],l={shell:".share-menu-tab-pgn-component, .share-menu-content",injectId:"cc2l-share-export-btn",downloadAnchors:[".share-menu-tab-pgn-component .cc-button-primary",".share-menu-content .cc-button-primary","#live_ShareMenuGlobalDialogDownloadButton","#chessboard_ShareMenuGlobalDialogDownloadButton",'[data-cy="share-menu-download-button"]','[data-cy*="download"]']},c={secondaryMenu:".game-controls-secondary-more > button, .game-controls-secondary-button > button",shareBtn:'[data-cy="sidebar-share-icon"], [data-cy="analysis-secondary-controls-menu-open-share"], button[aria-label="Share"], button.share-button-component.icon-share, button.share-button-component.share, #shareMenuButton',pgnTabActive:'#tab-pgn.cc-tab-item-active, [data-cy="pgn-tab-button"][aria-selected="true"]',pgnTab:'#tab-pgn, [data-cy="pgn-tab-button"], #live_ShareMenuGlobalDialogDownloadButton',dialogButtons:'dialog button, [role="dialog"] button, [class*="modal"] button, [class*="share"] button',textarea:'.share-menu-tab-pgn-textarea, #live_ShareMenuPgnContentTextareaId, textarea[name=pgn], textarea[aria-label="PGN"], #chessboard_ShareMenuPgnContentTextareaId',timestampsCheckbox:"#tab-pgn-timestamps",closeBtn:'.cc-close-button-component, [data-cy="modal-close-button"], #live_ShareMenuGlobalDialogCloseButton, button.ui_outside-close-component, #chessboard_ShareMenuGlobalDialogCloseButton'},V=["You Won","You Lost","Draw"];function p(t,e={}){const{timeoutMs:n=5e3,predicate:o}=e;return new Promise((r,a)=>{const f=Date.now()+n,s=()=>{const B=document.querySelector(t);if(B&&(!o||o(B))){r(B);return}if(Date.now()>=f){a(new Error(`waitForElement timed out: "${t}"`));return}setTimeout(s,100)};s()})}function w(t){return t.includes(" won on time")?t.replace(/Termination "[^"]+"/g,'Termination "Time forfeit"'):t.replace(/Termination "[^"]+"/g,'Termination "Normal"')}async function W(){const t=document.querySelector(c.secondaryMenu);t&&(t.click(),await p(c.shareBtn));const e=document.querySelector(c.shareBtn);if(!e)throw new Error("Share button not found");e.click(),await p(`${c.pgnTab}, ${c.textarea}`)}async function M(){if(document.querySelector(c.pgnTabActive))return;const t=document.querySelector(c.pgnTab)??Array.from(document.querySelectorAll(c.dialogButtons)).find(e=>{var n;return((n=e.textContent)==null?void 0:n.trim())==="PGN"});t&&(t.click(),await p(c.textarea))}function Y(){var t;(t=document.querySelector(c.closeBtn))==null||t.click()}function x(t){return(t.value||t.getAttribute("value")||t.textContent||"").trim()}async function _(){const t=document.querySelector(c.timestampsCheckbox);t!=null&&t.checked&&t.click();const e=await p(c.textarea,{predicate:n=>x(n).length>0});return x(e)}async function X(){await M();const t=w(await _());if(!/^\s*\[Event /m.test(t))throw new Error("PGN not ready in share dialog");return t}async function K(){await W(),await M();let t;try{t=w(await _())}finally{Y()}return t}async function Q(t){var n;const e=["live","daily"];for(const o of e){const r=`https://www.chess.com/callback/${o}/game/${t}`;try{const a=await fetch(r,{credentials:"include"});if(!a.ok)continue;const s=(n=(await a.json()).game)==null?void 0:n.pgn;if(s!=null&&s.trim())return w(s)}catch{}}throw new Error("Could not load PGN from chess.com API")}async function Z(t){const e=document.querySelector(c.textarea);if(e&&x(e).length>0)try{return await X()}catch{}try{return await K()}catch(n){if(!t)throw n;return Q(t)}}const u="cc2l_game_map";function E(t=window.location.pathname){const e=t.match(/\/(?:analysis\/)?game\/(?:[a-z-]+\/)?(\d+)/i);return e?e[1]:null}function L(){try{const t=d().storage.get(u,"{}");return JSON.parse(t)}catch{return{}}}function S(t){return L()[t]??null}function tt(t,e){const n=L();n[t]=e,d().storage.set(u,JSON.stringify(n))}async function et(){const t=E();if(t){const o=S(t);if(o){await d().tabs.open(o,!0);return}}const e=await Z(t);if(!e.includes("[Termination"))throw new Error("Game is not finished yet");const n=await H(e);t&&tt(t,n.url),await d().tabs.open(n.url,!0)}const T=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="80" height="80" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <path fill="currentColor" d="m37.656 74.009c-4.8354-0.36436-9.6886-1.699-13.955-3.8378-3.4383-1.7236-6.4517-3.92-9.0933-6.628-7.0896-7.2676-10.055-17.334-8.1548-27.684 1.5646-8.5227 6.1202-15.614 12.927-20.122 6.4164-4.2497 14.836-6.2637 24.632-5.8922l2.1764 0.082493 0.71448-0.46162c2.8371-1.8331 5.781-2.7675 10.74-3.409 1.3469-0.17424 1.5334-0.18309 1.7288-0.082031 0.24019 0.1242 0.31608 0.26074 0.31608 0.56864 0 0.11136-0.4595 2.1736-1.0211 4.5828-1.0078 4.3233-1.0194 4.3838-0.89332 4.6483 0.07031 0.14737 0.50749 0.95627 0.97159 1.7975 0.4641 0.84128 0.96793 1.7581 1.1196 2.0374 0.15171 0.2793 1.5664 2.8457 3.1439 5.7031 1.5774 2.8574 3.8363 6.9531 5.0198 9.1016 3.237 5.8763 4.9952 9.0631 5.4255 9.8339 0.50792 0.90969 0.63287 1.4871 0.62769 2.9005-0.0037 0.91614-0.03691 1.2203-0.20664 1.8732-0.86524 3.328-3.915 6.1562-8.8068 8.167-1.1079 0.45544-2.3332 0.85827-2.6106 0.85827-0.25397 0-0.38898-0.15415-1.129-1.2891-1.3352-2.0478-3.9112-4.9986-6.541-7.4929-1.5045-1.427-2.0154-1.8499-5.6466-4.6744-4.6142-3.5891-6.2759-5.0009-8.48-7.2045-3.9949-3.9941-5.887-7.2765-6.1716-10.706-0.08995-1.0838 0.18839-2.7981 0.50585-3.1155 0.41619-0.41619 1.1662-0.01476 1.064 0.56953-0.02694 0.15422-0.06902 0.65348-0.09347 1.1095-0.03663 0.68284-0.01606 0.94126 0.11629 1.4648 0.63768 2.5217 3.041 5.405 7.3949 8.8718 2.0126 1.6025 3.381 2.5855 7.6172 5.4717 5.194 3.5387 5.6984 3.9377 8.1641 6.4574 2.308 2.3586 3.494 3.8269 4.3474 5.3817 0.22404 0.4082 0.4147 0.75294 0.42366 0.7661 0.03949 0.05785 1.0174-0.24498 1.6091-0.49822 2.5156-1.0767 4.1441-3.2328 4.6375-6.1402l0.12817-0.75512-2.3219-3.8933c-1.2771-2.1413-2.9627-4.9656-3.7459-6.2761-2.1258-3.5573-10.258-17.183-10.81-18.114-0.26416-0.44496-0.4989-0.88442-0.52166-0.97656-0.0251-0.10167 0.35524-1.304 0.96742-3.0582 1.1589-3.3208 1.1586-3.0658 0.0028-2.7713-1.7885 0.45585-3.5267 1.2861-7.057 3.3706-0.71397 0.4216-1.2524 0.68973-1.385 0.68973-0.11934 0-0.6484-0.06957-1.1757-0.15451-2.4739-0.39872-5.0621-0.55615-7.5603-0.45987-5.5228 0.21286-10.604 1.8776-14.844 4.8634-4.762 3.3535-8.8329 8.8527-10.751 14.524-2.991 8.8413-0.68144 19.066 6.03 26.696 4.991 5.6739 11.828 9.2927 19.487 10.315 1.578 0.21053 4.5386 0.28823 6.1195 0.16059 7.0509-0.56924 13.253-3.3262 18.267-8.1207 0.79159-0.75686 0.94438-0.87009 1.174-0.87009 0.61003 0 0.83436 0.48111 0.49462 1.0608-0.76303 1.302-2.9045 3.6393-4.5382 4.9532-4.0237 3.236-9.0858 5.1841-14.924 5.7434-1.1092 0.10625-4.5728 0.1453-5.655 0.06376z"/>
</svg>
`,i={bragText:"hsl(37 100% 70%)",metalTop:"hsl(37 7% 22%)",metalBottom:"hsl(37 5% 19%)",border:"hsl(0 0% 25%)",textShadow:"none",buttonShadow:"0 1px 3px 0 hsl(0 0% 0% / 0.2)",radius:"3px"},g=`cc2l_${Math.random().toString(36).slice(2,10)}`,P=`${g}_style`,v={idle:`${T} Analyse on Lichess`,cached:`${T} Re-open on Lichess ✓`,loading:"⏳ Importing…",error:"❌ Failed — retry?"},C=`${T} Export to Lichess`;function nt(){return document.getElementById(g)!==null}function ot(){for(const t of J){const e=document.querySelector(t);if(e)return e}return rt()}function rt(){for(const t of V){const e=Array.from(document.querySelectorAll("*")).find(o=>Array.from(o.childNodes).filter(a=>a.nodeType===Node.TEXT_NODE).map(a=>{var f;return((f=a.textContent)==null?void 0:f.trim())??""}).join("").includes(t));if(!e)continue;let n=e;for(let o=0;o<8&&n&&(n=n.parentElement,!!n);o++){const r=Array.from(n.querySelectorAll('button, a, [role="button"]')).find(a=>/game review/i.test(a.textContent??""));if(r!=null&&r.parentElement)return r.parentElement}}return null}function at(t,e="idle"){const n=ot();if(!n)return!1;const o=document.createElement("button");o.id=g,o.type="button",o.className="cc2l-btn",o.innerHTML=v[e],o.addEventListener("click",t);const r=n.querySelector(".game-over-secondary-actions-row-component");return r?n.insertBefore(o,r):n.appendChild(o),I(),!0}function ct(t){const e=document.getElementById(g);e&&(e.innerHTML=v[t],e.disabled=t==="loading")}function I(){if(document.getElementById(P))return;const t=document.createElement("style");t.id=P,t.textContent=`
    .cc2l-btn,
    .cc2l-share-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      border: 1px solid ${i.border};
      border-radius: ${i.radius};
      background: linear-gradient(
        to bottom,
        ${i.metalTop},
        ${i.metalBottom}
      );
      color: ${i.bragText};
      font-weight: 500;
      text-shadow: ${i.textShadow};
      box-shadow: ${i.buttonShadow};
      cursor: pointer;
      transition: filter 0.15s, box-shadow 0.15s;
      box-sizing: border-box;
      font-family: inherit;
    }
    .cc2l-btn {
      padding: 2rem 4rem;
      margin-top: 8px;
      font-size: 22px;
    }
    [data-cy="game-over-modal-shell-buttons"] .cc2l-btn,
    .game-over-modal-shell-buttons .cc2l-btn {
      padding: 1.3rem 2rem;
      margin-top: 8px;
    }
    .cc2l-btn svg,
    .cc2l-share-btn svg {
      width: 24px;
      height: 24px;
      flex-shrink: 0;
    }
    .cc2l-share-btn {
      margin: 0;
      padding: 12px 16px;
      font-size: 16px;
    }
    .cc2l-share-actions {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 0 !important;
      padding-top: 0 !important;
    }
    .cc2l-share-actions .cc2l-share-btn,
    .cc2l-share-actions > .cc-button-primary,
    .cc2l-share-actions > button {
      margin: 0 !important;
    }
    .cc2l-share-btn svg {
      width: 20px;
      height: 20px;
    }
    .cc2l-btn:hover:not(:disabled),
    .cc2l-share-btn:hover:not(:disabled) {
      filter: brightness(1.12);
    }
    .cc2l-btn:disabled,
    .cc2l-share-btn:disabled {
      opacity: 0.65;
      cursor: not-allowed;
    }
  `,document.head.appendChild(t)}function A(t){const e=getComputedStyle(t);if(e.display==="none"||e.visibility==="hidden")return!1;const n=t.getBoundingClientRect();return n.width>=8&&n.height>=8}function it(t){return`${t.textContent??""} ${t.getAttribute("aria-label")??""}`}function N(t){for(const n of l.downloadAnchors){const o=t.querySelector(n);if(o&&A(o))return o}const e=t.querySelectorAll('button, a[role="button"], a[download]');return Array.from(e).find(n=>/download/i.test(it(n)))??null}function st(t){return t instanceof HTMLDialogElement?t.open:A(t)}function O(){for(const t of Array.from(document.querySelectorAll("dialog.cc-modal-component-v2, dialog"))){if(!st(t))continue;const e=t.querySelector(l.shell)??t,n=N(e),o=e.querySelector('textarea[name=pgn], textarea[aria-label="PGN"], .share-menu-tab-pgn-textarea');if(n!=null&&n.parentElement&&o)return{container:e,downloadBtn:n}}for(const t of Array.from(document.querySelectorAll('textarea[name=pgn], textarea[aria-label="PGN"], .share-menu-tab-pgn-textarea'))){if(!A(t))continue;let e=t;for(let n=0;n<20&&e;n++){const o=N(e);if(o!=null&&o.parentElement)return{container:e,downloadBtn:o};e=e.parentElement}}return null}function lt(){return O()!==null}function ut(){const t=document.getElementById(l.injectId);if(!t)return;const e=t.parentElement;t.remove(),e==null||e.classList.remove("cc2l-share-actions")}function dt(t){const e=O();if(!e||document.getElementById(l.injectId))return;const{downloadBtn:n}=e;if(!n.parentElement)return;const o=document.createElement("button");o.id=l.injectId,o.type="button",o.className="cc2l-share-btn",o.innerHTML=C,o.addEventListener("click",t),I();const r=n.parentElement;r.classList.add("cc2l-share-actions"),r.insertBefore(o,n)}function mt(t){const e=document.getElementById(l.injectId);e&&(e.innerHTML=t==="idle"?C:v[t],e.disabled=t==="loading")}function ht(){document.querySelectorAll(".cc2l-btn, .cc2l-share-btn").forEach(t=>t.remove()),document.querySelectorAll('style[id^="cc2l_"][id$="_style"]').forEach(t=>t.remove())}function b(){if(typeof chrome>"u"||!chrome.runtime)return!0;try{return chrome.runtime.id,!0}catch{return!1}}function ft(t){const e=t instanceof Error?t.message:String(t);return e.includes("Extension context invalidated")?"Extension was reloaded — refresh this page and try again":e.includes("Receiving end does not exist")?"Extension service worker unavailable — refresh this page and try again":e}let m=null;function k(){return U.some(t=>window.location.pathname.includes(t))}function pt(){return z.some(t=>document.querySelector(t)!==null)}function gt(){const t=E();return t&&S(t)?"cached":"idle"}async function D(t){t("loading");try{await et(),t("cached")}catch(e){console.error("[chesscom-lichess-export]",ft(e)),t("error");const n=E(),o=n&&S(n)?"cached":"idle";setTimeout(()=>t(o),3e3)}}function q(){!k()||pt()||nt()||at(()=>{D(ct)},gt())}function G(){if(k()){if(!lt()){ut();return}dt(()=>{D(mt)})}}function $(){m||(m=setInterval(()=>{if(!b()){R();return}q(),G()},500),q(),G())}function R(){m&&(clearInterval(m),m=null),ht()}let h={};async function j(t){if(!b())throw new Error("Extension context invalidated");let e;for(let n=0;n<2;n++){try{const o=await chrome.runtime.sendMessage(t);if(o!==void 0)return o}catch(o){if(e=o,!b())throw o}await new Promise(o=>setTimeout(o,150))}throw e??new Error("Extension service worker unavailable")}async function bt(){const t=await chrome.storage.local.get(u);try{h=JSON.parse(t[u]??"{}")}catch{h={}}F({storage:{get(n,o){return n===u?JSON.stringify(h):o},set(n,o){if(n===u)try{h=JSON.parse(o)}catch{h={}}b()&&chrome.storage.local.set({[n]:o})}},http:{async postForm(n,o,r){const a=await j({type:"HTTP_POST_FORM",url:n,data:o,headers:r});if(!a.ok)throw new Error(a.error??"Extension HTTP request failed");return{status:a.status??0,responseText:a.responseText??""}}},tabs:{async open(n,o=!0){const r=await j({type:"OPEN_TAB",url:n,active:o});if(!r.ok)throw new Error(r.error??"Failed to open tab")}}})}async function yt(){await bt(),document.documentElement.dataset.cc2lExtension="1",typeof GM_info<"u"&&console.warn("[cc2l] Userscript detected; extension takes precedence. Disable the userscript to avoid duplicate UI."),$()}yt(),chrome.runtime.onMessage.addListener(t=>{t.type==="DEV_RELOAD"&&(R(),$())})})();
